public class ComLeite extends CafeDecorator {
    public ComLeite(Cafe cafe) {
        super(cafe);
    }
    @Override
    public String getDescricao() {
        return cafe.getDescricao() + ", Cafe com Leite";
    }
    @Override
    public  double getPreco() {
        return cafe.getPreco() + 1.50;
    }
}
