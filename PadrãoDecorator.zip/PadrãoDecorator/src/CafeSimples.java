public class CafeSimples implements Cafe {
    @Override
    public String getDescricao() {
        return "Cafe simples";
    }

    @Override
    public double getPreco() {
        return 2.0;
    }
}
