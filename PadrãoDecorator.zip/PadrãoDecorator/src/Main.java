public class Main {
    public static void main(String[] args) {

        Cafe pedido1 = new CafeSimples();
        System.out.println(pedido1.getDescricao() + " → R$ " + pedido1.getPreco());


        Cafe pedido2 = new ComLeite(new CafeSimples());
        System.out.println(pedido2.getDescricao()+ " → R$ " + pedido2.getPreco());
    }
}
